<?php
// Database connection
$servername = "localhost";  // Change if your DB server is different
$username = "root";         // Your DB username
$password = "";             // Your DB password
$dbname = "beauty_parlour"; // The database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
