<?php
include('database.php');


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);  // Hash password

    // Insert user into database
    $sql = "INSERT INTO users (username, email, password) VALUES ('$username', '$email', '$password')";

    if ($conn->query($sql) === TRUE) {
        echo "Signup successful!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beauty Parlour Management System - Sign Up</title>
    <style>
        body {
            font-family:  Arial, sans-serif;
            margin: 0;
            padding: 0;
            text-align: center;
            background-image: url("backimage1.jpeg");
            background-repeat: no-repeat;  
            background-size: cover;
            background-position: center;
            padding: 10px 0;
            width: 100%;
            height: 800px;
        }

        header {
            background-color:#ff69b4;
            color: white;
            padding: 20px 0;
            text-align: center;
            z-index: 1;
        }

        nav {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 20px;
            background-color: black;
        }

        nav a {
            color: white;
            padding: 14px 20px;
            text-decoration: none;
        }

        nav a:hover {
            background-color: #ddd;
            color: black;
        }

        .signup-container {
            background-color: white;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-top: 50px;
            width: 300px;
            text-align: left;
            margin: auto;
        }

        .signup-container h2 {
            color: #f78cc1;
        }

        .signup-container input {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        .signup-container input[type="submit"] {
            background-color: #f78cc1;
            color: white;
            cursor: pointer;
            border: none;
            font-size: 16px;
        }

        .signup-container input[type="submit"]:hover {
            background-color: #f56e96;
        }

        .signup-container .signup-btn {
            background-color: #f78cc1;
            color: white;
            font-size: 16px;
            padding: 12px;
            border: none;
            cursor: pointer;
            width: 100%;
            border-radius: 5px;
        }

        .signup-container .signup-btn:hover {
            background-color: #f56e96;
        }

        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px 0;
        }

        .login {
            color: #f78cc1;
        }

        .login a {
            text-decoration: none;
            color: #f78cc1;
        }

        .login a:hover {
            color: #f56e96;
        }

        #home-link {
            color: #f78cc1;
        }

        #home-link:hover {
            color: #f56e96;
        }
    </style>
</head>
<body>
    <header>
        <h1>Beauty Parlour Management System</h1>
        <nav>
            <a href="index.html">Home</a>
            <a href="about.html">About</a>
            <a href="service.html">Services</a>
            <a href="signup.php">Appointment</a>
            <a href="feedback.php">Feedback</a>
            <a href="admin.php">Admin</a>
        </nav>
    </header>
<body>
    <div class="signup-container">     
        <h2><i class="fa-solid fa-car" style="color: #e74008;"></i> Sign Up</h2>
        <form id="signup-form" action="login.php" method="POST" onsubmit="return validateSignupForm()">
            <div class="input-group">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" placeholder="Choose a username" required>
            </div>
            <div class="input-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" placeholder="Enter your email" required>
            </div>
            <div class="input-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" placeholder="Create a password" required>
            </div>
            <div class="input-group">
                <label for="confirm-password">Confirm Password:</label>
                <input type="password" id="confirm-password" name="confirm-password" placeholder="Confirm your password" required>
            </div>
            <button type="submit" class="signup-btn">Sign Up <a href="login.php"><i class="fa-solid fa-user-plus"></i></button>
            <p class="login">Already have an account? <a href="login.php" class="login1">Login</a></p>
        </form>
        <p><a href="index.html" id="home-link">Go to home page</a></p>
    </div>
</body>
</html>

    <footer>
        <p>&copy; 2025 Beauty Parlour. All Rights Reserved.</p>
    </footer>
</body>
</html>
