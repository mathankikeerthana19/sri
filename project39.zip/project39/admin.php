
<?php
// Database connection settings
$servername = "localhost";  // Database server
$username = "root";         // Database username
$password = "";             // Database password
$dbname = "beauty_parlour"; // Database name

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check if the connection was successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form input values
    $username = $_POST['username'];
    $password = $_POST['password']; // Password entered by the user

    // Query to get admin user details from the database
    $sql = "SELECT * FROM admin_users WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Fetch the admin user data
        $user = $result->fetch_assoc();
        
        // Verify the password using password_verify
        if (password_verify($password, $user['password'])) {
            // Start session and store user information
            session_start();
            $_SESSION['admin_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            
            // Redirect to the admin dashboard or home page
            header("Location: admin.php");
            exit();
        } else {
            $error = "Invalid password.";
        }
    } else {
        $error = "No such user found.";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - Beauty Parlour Management System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            text-align: center;
            background-image: url("backimage1.jpeg");
            background-repeat: no-repeat;
            background-size: cover;
            background-position: center;
            padding: 10px 0;
            width: 100%;
            height: 750px;
        }
    
        header {
            background-color:#ff69b4;
            color: white;
            padding: 20px 0;
            text-align: center;
            z-index: 1;
        }

        nav {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 20px;
            background-color: black;
        }

        nav a {
            color: white;
            padding: 14px 20px;
            text-decoration: none;
        }

        nav a:hover {
            background-color: #ddd;
            color: black;
        }

        .login-container {
            background-color: white;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-top: 50px;
            width: 300px;
            text-align: left;
            margin: auto;
        }

        .login-container h2 {
            color: #f78cc1;
        }

        .login-container input {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        .login-container input[type="submit"] {
            background-color: #f78cc1;
            color: white;
            cursor: pointer;
            border: none;
            font-size: 16px;
        }

        .login-container input[type="submit"]:hover {
            background-color: #f56e96;
        }

        .error {
            color: red;
            font-size: 14px;
            text-align: center;
        }

        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 15px 0;
            position: relative;
            bottom: 0;
            width: 100%;
        }

        .footer a {
            color: white;
            text-decoration: none;
        }

        .footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<header>
    <h1>Beauty Parlour Management System</h1>
    <nav>
        <a href="index.html">Home</a>
        <a href="about.html">About</a>
        <a href="service.html">Services</a>
        <a href="signup.php">Appointment</a>
        <a href="feedback.php">Feedback</a>
        <a href="admin.php">Admin</a>
    </nav>
</header>

<div class="login-container">
    <h2>Admin Login</h2>
    <form action="admin.php" method="POST">
        <label for="username">Username</label><br>
        <input type="text" id="username" name="username" required><br>

        <label for="password">Password</label><br>
        <input type="password" id="password" name="password" required><br>

        <input type="submit" value="Login">
    </form>

    <?php
    // Display error if any
    if (isset($error)) {
        echo "<p class='error'>$error</p>";
    }
    ?>
</div>

<footer>
    <p>&copy; 2025 Beauty Parlour. All Rights Reserved.</p>
</footer>
</body>
</html>
