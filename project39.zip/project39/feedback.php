<?php
// Database connection settings
$servername = "localhost";  // Database server
$username = "root";         // Database username
$password = "";             // Database password
$dbname = "beauty_parlour"; // Database name

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check if the connection was successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Start the session to store feedback success message
session_start();

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form input values
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $service = mysqli_real_escape_string($conn, $_POST['service']);
    $message = mysqli_real_escape_string($conn, $_POST['message']);
    
    // Prepare and bind the SQL statement
    $stmt = $conn->prepare("INSERT INTO feedback (name, email, service, message) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $name, $email, $service, $message);
    
    // Execute the statement
    if ($stmt->execute()) {
        $_SESSION['feedback_success'] = "Thank you for your Feedback!";
        header("Location: feedback.php"); // Redirect to the same page to display success message
        exit();
    } else {
        $_SESSION['feedback_error'] = "Error submitting feedback. Please try again later.";
        header("Location: feedback.php"); // Redirect to display error message
        exit();
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback - Beauty Parlour Management System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            text-align: center;
            background-image: url("backimage1.jpeg");
            background-repeat: no-repeat;
            background-size: cover;
            background-position: center;
            padding: 10px 0;
            width: 100%;
            height: 100%;
        }

        header {
            background-color: #ff69b4;
            color: white;
            padding: 20px 0;
            text-align: center;
            z-index: 1;
        }

        nav {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 20px;
            background-color: black;
        }

        nav a {
            color: white;
            padding: 14px 20px;
            text-decoration: none;
        }

        nav a:hover {
            background-color: #ddd;
            color: black;
        }

        .feedback-container {
            background-color: white;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-top: 50px;
            width: 300px;
            text-align: left;
            margin: auto;
        }

        .feedback-container h2 {
            color: #f78cc1;
        }

        .feedback-container input,
        .feedback-container textarea,
        .feedback-container select {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        .feedback-container textarea {
            height: 150px;
            resize: vertical;
        }

        .feedback-container input[type="submit"] {
            background-color: #f78cc1;
            color: white;
            cursor: pointer;
            border: none;
            font-size: 16px;
        }

        .feedback-container input[type="submit"]:hover {
            background-color: #f56e96;
        }

        .feedback-message {
            color: green;
            font-weight: bold;
            margin-top: 20px;
        }

        .feedback-error {
            color: red;
            font-weight: bold;
            margin-top: 20px;
        }

        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px 0;
        }
    </style>
</head>
<body>
    <header>
        <h1>Beauty Parlour Management System</h1>
        <nav>
            <a href="index.html">Home</a>
            <a href="about.html">About</a>
            <a href="service.html">Services</a>
            <a href="signup.php">Appointment</a>
            <a href="feedback.php">Feedback</a>
            <a href="admin.php">Admin</a>
        </nav>
    </header>
    <div class="feedback-container">
        <h2>Feedback</h2>
        <form action="feedback.php" method="POST">
            <label for="name">Your Name</label><br>
            <input type="text" id="name" name="name" required placeholder="Enter your name"><br>

            <label for="email">Your Email</label><br>
            <input type="email" id="email" name="email" required placeholder="Enter your email"><br>

            <label for="service">Service Received</label><br>
            <select id="service" name="service" required>
                <option value="Bridal Makeup">Bridal Makeup</option>
                <option value="Mehendi">Mehendi</option>
                <option value="Hairstyling">Hairstyling</option>
                <option value="Skin Treatments">Skin Treatments</option>
            </select><br>

            <label for="message">Your Feedback</label><br>
            <textarea id="message" name="message" required placeholder="Enter your feedback"></textarea><br>

            <input type="submit" value="Submit Feedback">
        </form>

        <!-- Display success or error message below the form -->
        <?php
        
        if (isset($_SESSION['feedback_success'])) {
            echo "<div class='feedback-message'>" . $_SESSION['feedback_success'] . "</div>";
            unset($_SESSION['feedback_success']); // Clear the message after showing it
        }
        if (isset($_SESSION['feedback_error'])) {
            echo "<div class='feedback-error'>" . $_SESSION['feedback_error'] . "</div>";
            unset($_SESSION['feedback_error']); // Clear the error message after showing it
        }
        ?>
    </div>

    <footer>
        <p>&copy; 2025 Beauty Parlour. All Rights Reserved.</p>
    </footer>
</body>
</html>
