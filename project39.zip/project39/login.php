<?php
include('database.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Check if user exists
    $sql = "SELECT * FROM users WHERE username = '$username'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Fetch user data
        $user = $result->fetch_assoc();
        
        // Verify password
        if (password_verify($password, $user['password'])) {
            echo "Login successful!";
            header('location: appointment.php');
            // Redirect or create a session for logged-in user
        } else {
            echo "Invalid password!";
        }
    } else {
        echo "No user found with that email!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Beauty Parlour Management System</title>
    <style>
        body {
            font-family:  Arial, sans-serif;
            margin: 0;
            padding: 0;
            text-align: center;
            background-image: url("backimage1.jpeg");
            background-repeat: no-repeat;  
            background-size: cover;
            background-position: center;
            padding: 10px 0;
            width: 100%;
            height: 800px;
        }

        header {
            background-color:#ff69b4;
            color: white;
            padding: 20px 0;
            text-align: center;
            z-index: 1;
        }

        nav {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 20px;
            background-color: black;
        }

        nav a {
            color: white;
            padding: 14px 20px;
            text-decoration: none;
        }

        nav a:hover {
            background-color: #ddd;
            color: black;
        }

        .login-container {
            background-color: white;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-top: 50px;
            width: 300px;
            text-align: left;
            margin: auto;
        }

        .login-container h2 {
            color: #f78cc1;
        }

        .login-container input {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        .login-container input[type="submit"] {
            background-color: #f78cc1;
            color: white;
            cursor: pointer;
            border: none;
            font-size: 16px;
        }

        .login-container input[type="submit"]:hover {
            background-color: white;
        }

        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px 0;
        }
        .signup {
            color: #f78cc1;
        }

        .signup a {
            text-decoration: none;
            color: #f78cc1;
        }

        .signup a:hover {
            color: #f56e96;
        }

        #home-link {
            color: #f78cc1;
        }

        #home-link:hover {
            color: #f56e96;
        }

        .login-btn {
            background-color: #f78cc1;
            color: white;
            font-size: 16px;
            padding: 12px;
            border: none;
            cursor: pointer;
            width: 100%;
            border-radius: 5px;
        }

        .login-btn:hover {
            background-color: #f56e96;
        }
    </style>
</head>
<body>
    <header>
        <h1>Beauty Parlour Management System</h1>
        <nav>
            <a href="index.html">Home</a>
            <a href="about.html">About</a>
            <a href="service.html">Services</a>
            <a href="signup.php">Appointment</a>
            <a href="feedback.php">Feedback</a>
            <a href="admin.php">Admin</a>
        </nav>
    </header>
<body>
<div class="login-container">     
        <h2><i class="fa-solid fa-car" style="color: #e74008;"></i>Login</h2>
        <form id="login-form" action="login.php" method="POST" onsubmit="return validateForm()">
            <div class="input-group">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" placeholder="Enter your username" required>
            </div>
            <div class="input-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" placeholder="Enter your password" required>
            </div>
            <button type="submit" class="login-btn"> <a href="appointment.php">Login <i class="fa-solid fa-right-to-bracket"></i></a>
</button>
            <p class="signup">Don't have an account? <a href="appointment.php" class="signup1">Sign Up</a></p>
        </form>
        <p><a href="index.html" id="home-link">go to home page</a></p>

    </div>
    <footer>
        <p>&copy; 2025 Beauty Parlour.All Rights Reserved.</p>
    </footer>
</body>
</html>

